## Characters rebalance
*original idea and planning by FantasyJared*

The biggest part of the rebalance mod.  
Just kindly read the changelist, please. Or look at the Encyclopedia.  
Note that most of the shared skills got quite a bit stronger.  


Thanks to **windypanda1** for implementing Azar and Johan!

---
[Full list of changes (*nearly* 100% accurate)](https://docs.google.com/document/d/120mZExGCaLq8Vvc6D7XcMur9-v53euveqXbF9XS03Ug/edit?usp=sharing)  
[Community Discord](https://discord.gg/mdgNC4pYjR) *Don't hesitate to ask for support!*

---
[*Manual install instructions*](https://github.com/Neoshrimp/ChronoArk-gameplay-plugins#installation)  
**Manual install is the only option for 32-bit version**