## Equipment tweaks
*original idea and planning by FantasyJared*

Changes stats and behavior of equipment, relics and potions.  
Most the equipment got some sort of change. Overall, it's a bit of an improvement but nothing too wild.  
As for relics and potions only the very overpowered/underpowered items were tweaked.


---
[Full list of changes (*nearly* 100% accurate)](https://docs.google.com/document/d/120mZExGCaLq8Vvc6D7XcMur9-v53euveqXbF9XS03Ug/edit?usp=sharing)  
[Community Discord](https://discord.gg/mdgNC4pYjR) *Don't hesitate to ask for support!*

---
[*Manual install instructions*](https://github.com/Neoshrimp/ChronoArk-gameplay-plugins#installation)  
**Manual install is the only option for 32-bit version**