## System Tweaks
*original idea and planning by FantasyJared*

Minor changes benefiting the player but, honestly, the impact is pretty negligible so it can be considered a quality of life improvement.


---
[Full list of changes (*nearly* 100% accurate)](https://docs.google.com/document/d/120mZExGCaLq8Vvc6D7XcMur9-v53euveqXbF9XS03Ug/edit?usp=sharing)  
[Community Discord](https://discord.gg/mdgNC4pYjR) *Don't hesitate to ask for support!*

---
[*Manual install instructions*](https://github.com/Neoshrimp/ChronoArk-gameplay-plugins#installation)  
**Manual install is the only option for 32-bit version**
